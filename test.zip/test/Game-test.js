import {Game} from './../lib/Game.js';
import {Chai} from 'chai';

describe ('Game', function() {
    it('should be a function' 
    )
})